
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'FreeRTOS_3LevelPJ' 
 * Target:  'FreeRTOS_3LevelPJ' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f10x.h"



#endif /* RTE_COMPONENTS_H */
