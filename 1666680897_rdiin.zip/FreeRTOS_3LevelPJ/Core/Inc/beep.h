/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    beep.h
  * @brief   This file contains all the function prototypes for
  *          the beep.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BEEP_H__
#define __BEEP_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */
#include "FreeRTOS.h"
#include "portmacro.h"
#include "systick.h"
/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */
#if 1
#define PBout(n) BIT_ADDR(GPIOB_ODR_Addr,n)
#define PBeep PBout(5)
#define BEEP_PORT   GPIOA
#define BEEP_PIN      GPIO_PIN_15
#define BEEP_PORT_RCC RCC_APB2Periph_GPIOB
#endif
/* USER CODE END Private defines */

/* USER CODE BEGIN Prototypes */
void BEEP_Init(void);
void Sound(u16 frq);
void play(void);
/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif
#endif /*__ SEG_H__ */

